import 'package:aula_firebase/homePage.dart';
import 'package:aula_firebase/listPerson.dart';
import 'package:aula_firebase/login.dart';
import 'package:flutter/material.dart';


class AppRoutes {
  static const homePage = '/homePage';
  static const listPerson = '/listPerson';
  static const login = '/login';

  static Map<String, WidgetBuilder> define(){
    return {
      homePage: (BuildContext context) => HomePage(),
      listPerson: (BuildContext context) => ListPerson(),
      login: (BuildContext context) => Login(),
    };
  }
}