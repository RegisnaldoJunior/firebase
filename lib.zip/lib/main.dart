import 'package:aula_firebase/AppRoutes.dart';
import 'package:flutter/material.dart';
import 'package:aula_firebase/listPerson.dart';

import 'homePage.dart';

void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    initialRoute: AppRoutes.homePage,
    routes: AppRoutes.define(),
  ));
}